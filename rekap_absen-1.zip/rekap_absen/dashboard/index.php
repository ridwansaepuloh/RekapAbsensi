<?php
session_start();

// Logout handler PHP
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    session_unset();
    session_destroy();
    header('Location: ../login/index.php');
    exit;
}

header('Content-Type: text/html; charset=UTF-8');
$tahunAktif = 2026;
$appTitle = "Dashboard Admin - Rekap Absensi " . $tahunAktif;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $appTitle; ?></title>
    <meta name="description" content="Dashboard admin untuk rekap absensi siswa <?php echo $tahunAktif; ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../asset/style.css">
</head>
<body>

<div class="dashboard-wrapper">

    <!-- ========== SIDEBAR ========== -->
    <aside class="sidebar">
        <div class="sidebar-brand">
            <div class="sidebar-brand-icon">
                <img src="../asset/image/notebook.png" alt="Absensi">
            </div>
            <div>
                <div class="sidebar-brand-name">ABSENSI</div>
                <div class="sidebar-brand-sub">Sistem Rekap</div>
            </div>
        </div>

        <nav class="sidebar-nav">
            <div class="nav-section-label">Menu Utama</div>
            <a class="nav-item active" href="#" id="nav-dashboard"
               onclick="setActiveNav(this); return false;">
                <img class="nav-icon" src="../asset/image/ikondashboard.jpg" alt="Dashboard">
                Dashboard
            </a>
            <a class="nav-item" href="#areaCetak" id="nav-rekap"
               onclick="setActiveNav(this); muatData(); scrollToEl('areaCetak');">
                <img class="nav-icon" src="../asset/image/ikonrekap.jpg" alt="Rekap">
                Rekap Absensi
            </a>
            <hr class="sidebar-divider">
            <div class="nav-section-label">Kelola Data</div>
            <a class="nav-item" href="#formTambahSiswa" id="nav-siswa"
               onclick="setActiveNav(this); tampilkanFormTambahSiswa(); scrollToEl('formTambahSiswa');">
                <img class="nav-icon" src="../asset/image/ikondata.jpg" alt="Data Siswa">
                Data Siswa
            </a>
            <a class="nav-item" href="#formLibur" id="nav-libur"
               onclick="setActiveNav(this); tampilkanFormLibur(); scrollToEl('formLibur');">
                <img class="nav-icon" src="../asset/image/ikonkalender.jpg" alt="Hari Libur">
                Hari Libur
            </a>
            <hr class="sidebar-divider">
            <div class="nav-section-label">Lainnya</div>
            <a class="nav-item" href="#" id="nav-cetak"
               onclick="setActiveNav(this); cetakLaporan(); return false;">
                <img class="nav-icon" src="../asset/image/ikonprint.jpg" alt="Cetak">
                Cetak / Print
            </a>
        </nav>

        <div class="sidebar-footer">
            <div class="user-pill">
                <div class="user-avatar">
                    <img src="../asset/image/ikonAdmin.jpg" alt="Admin">
                </div>
                <div>
                    <div class="user-name">Admin</div>
                    <div class="user-role">Administrator</div>
                </div>
            </div>
        </div>
    </aside>

    <!-- ========== MAIN CONTENT ========== -->
    <main class="main-content">

        <!-- Top Bar -->
        <div class="topbar">
            <div class="topbar-title">
                <h1>
                    <img src="../asset/image/ikondashboard.jpg" alt="" style="width:28px;height:28px;object-fit:contain;border-radius:6px;vertical-align:middle;">
                    Dashboard Admin
                </h1>
                <p id="topbar-subtitle">Rekap Absensi Siswa</p>
            </div>
            <div class="topbar-actions">
                <button type="button" class="btn btn-ghost btn-sm" onclick="cetakLaporan()">
                    <img src="../asset/image/ikonprint.jpg" alt="" style="width:14px;height:14px;object-fit:contain;"> Cetak
                </button>
                <button type="button" class="btn-logout" id="tombolLogout" onclick="logout()">
                    <img src="../asset/image/ikonsetelan.jpg" alt="" style="width:14px;height:14px;object-fit:contain;"> Logout
                </button>
            </div>
        </div>

        <!-- Stats -->
        <div class="stats-grid" id="statsGrid">
            <div class="stat-card">
                <div class="stat-icon pink"><img src="../asset/image/ikon_siswa.png" alt="Jumlah Siswa"></div>
                <div><div class="stat-val" id="statSiswa">0</div><div class="stat-label">Jumlah Siswa</div></div>
            </div>
            <div class="stat-card">
                <div class="stat-icon rose"><img src="../asset/image/ikon_kalender.png" alt="Hari Efektif"></div>
                <div><div class="stat-val" id="statHariEfektif">0</div><div class="stat-label">Hari Efektif</div></div>
            </div>
            <div class="stat-card">
                <div class="stat-icon green"><img src="../asset/image/ikon_hadir.png" alt="Hadir"></div>
                <div><div class="stat-val" id="statH">0</div><div class="stat-label">Hadir</div></div>
            </div>
            <div class="stat-card">
                <div class="stat-icon yellow"><img src="../asset/image/ikon_sakit.png" alt="Sakit"></div>
                <div><div class="stat-val" id="statS">0</div><div class="stat-label">Sakit</div></div>
            </div>
            <div class="stat-card">
                <div class="stat-icon blue"><img src="../asset/image/ikon_izin.png" alt="Izin"></div>
                <div><div class="stat-val" id="statI">0</div><div class="stat-label">Izin</div></div>
            </div>
            <div class="stat-card">
                <div class="stat-icon mauve"><img src="../asset/image/ikon_alpha.png" alt="Alpha"></div>
                <div><div class="stat-val" id="statA">0</div><div class="stat-label">Alpha</div></div>
            </div>
        </div>

        <!-- Keterangan Status (Sinkron Warna Spreadsheet) -->
        <div class="keterangan-bar">
            <span style="font-size:0.73rem;font-weight:600;color:var(--text-mid);margin-right:4px;">Keterangan:</span>
            <div class="keterangan-item">
                <span class="keterangan-badge" style="background:#d9ead3;color:#274e13;border:1px solid #b6d7a8;">H</span> Hadir
            </div>
            <div class="keterangan-item">
                <span class="keterangan-badge" style="background:#fff2cc;color:#7f6000;border:1px solid #ffe599;">S</span> Sakit
            </div>
            <div class="keterangan-item">
                <span class="keterangan-badge" style="background:#c9daf8;color:#1155cc;border:1px solid #a4c2f4;">I</span> Izin
            </div>
            <div class="keterangan-item">
                <span class="keterangan-badge" style="background:#f4cccc;color:#990000;border:1px solid #ea9999;">A</span> Alpha
            </div>
            <div class="keterangan-item">
                <span class="keterangan-badge" style="background:#f4cccc;border:1.5px solid #ea9999;width:18px;height:18px;min-width:18px;display:inline-block;border-radius:4px;vertical-align:middle;"></span> Tanggal Merah / Libur
            </div>
        </div>

        <!-- Period Picker (Tahun 2026 Tetap, Pilih Bulan Saja) -->
        <div class="glass-card period-card">
            <div class="card-header">
                <div class="card-header-icon"><img src="../asset/image/ikon_kalender.png" alt="Periode"></div>
                <div class="card-title">Pilih Periode Presensi</div>
            </div>
            <div class="period-controls">
                <label for="pilihBulan">Bulan:</label>
                <select id="pilihBulan" class="styled-select" onchange="muatData()">
                    <option value="0">Januari</option>
                    <option value="1">Februari</option>
                    <option value="2">Maret</option>
                    <option value="3">April</option>
                    <option value="4">Mei</option>
                    <option value="5">Juni</option>
                    <option value="6">Juli</option>
                    <option value="7">Agustus</option>
                    <option value="8">September</option>
                    <option value="9">Oktober</option>
                    <option value="10">November</option>
                    <option value="11">Desember</option>
                </select>
                <span style="font-size:0.85rem;font-weight:600;color:var(--text-mid);padding:8px 14px;background:rgba(255,255,255,0.7);border-radius:var(--radius-sm);border:1.5px solid var(--rose-mid);">Tahun <?php echo $tahunAktif; ?></span>
                <input type="hidden" id="pilihTahun" value="<?php echo $tahunAktif; ?>">
                <button type="button" class="btn btn-primary" onclick="muatData()">
                    <img src="../asset/image/ikonrekap.jpg" alt="" style="width:14px;height:14px;object-fit:contain;"> Segarkan Data
                </button>
            </div>
        </div>

        <!-- Action Bar -->
        <div class="action-bar">
            <button type="button" class="btn btn-primary" onclick="tampilkanFormTambahSiswa()">
                <img src="../asset/image/ikondata.jpg" alt="" style="width:14px;height:14px;object-fit:contain;"> + Tambah Siswa
            </button>
            <button type="button" class="btn btn-secondary" onclick="tampilkanFormLibur()">
                <img src="../asset/image/ikonkalender.jpg" alt="" style="width:14px;height:14px;object-fit:contain;"> Kelola Hari Libur
            </button>
            <button type="button" class="btn btn-ghost" onclick="cetakLaporan()">
                <img src="../asset/image/ikonprint.jpg" alt="" style="width:14px;height:14px;object-fit:contain;"> Cetak / Print
            </button>
        </div>

        <!-- Form Tambah Siswa -->
        <div id="formTambahSiswa" class="glass-card panel-form">
            <div class="panel-title"><i class="fa-solid fa-user-plus"></i> Tambah Siswa Baru</div>
            <div class="form-row">
                <div class="form-field">
                    <label for="inputNamaSiswa">Nama Siswa</label>
                    <input type="text" id="inputNamaSiswa" placeholder="Masukkan nama siswa">
                </div>
                <button type="button" class="btn btn-primary" onclick="simpanSiswa()"><i class="fa-solid fa-floppy-disk"></i> Simpan</button>
                <button type="button" class="btn btn-ghost" onclick="tutupForm('formTambahSiswa')"><i class="fa-solid fa-xmark"></i> Batal</button>
            </div>
            <p class="panel-msg" id="pesanTambahSiswa"></p>
        </div>

        <!-- Form Kelola Hari Libur -->
        <div id="formLibur" class="glass-card panel-form">
            <div class="panel-title"><i class="fa-solid fa-calendar-days"></i> Kelola Hari Libur (Tahun 2026)</div>
            <div class="form-row">
                <div class="form-field">
                    <label for="tanggalLibur">Tanggal Libur (2026)</label>
                    <input type="date" id="tanggalLibur" min="2026-01-01" max="2026-12-31">
                </div>
                <div class="form-field">
                    <label for="keteranganLibur">Keterangan</label>
                    <input type="text" id="keteranganLibur" placeholder="misal: Hari Libur Nasional">
                </div>
                <button type="button" class="btn btn-primary" onclick="tetapkanLibur()">
                    <i class="fa-solid fa-check"></i> Tetapkan Libur (Segaris Merah)
                </button>
                <button type="button" class="btn btn-secondary" onclick="batalkanLibur()">
                    <i class="fa-solid fa-ban"></i> Batalkan Libur
                </button>
                <button type="button" class="btn btn-ghost" onclick="tutupForm('formLibur')">
                    <i class="fa-solid fa-xmark"></i> Tutup
                </button>
            </div>
            <p class="panel-msg" id="pesanLibur"></p>
            <div id="daftarLiburBulanIni" style="margin-top:12px;"></div>
        </div>

        <!-- Form Edit Data Absensi Siswa -->
        <div id="formEditStatus" class="glass-card panel-form">
            <div class="panel-title"><i class="fa-solid fa-pen-to-square"></i> Ubah Data Absensi Siswa</div>
            <div class="form-row">
                <div class="form-field">
                    <label for="editNamaSiswa">Nama Siswa</label>
                    <input type="text" id="editNamaSiswa" readonly style="background:rgba(255,255,255,0.7);font-weight:600;">
                </div>
                <div class="form-field">
                    <label for="editPilihTanggal">Tanggal</label>
                    <select id="editPilihTanggal" onchange="onGantiTanggalEdit()"></select>
                </div>
                <div class="form-field">
                    <label for="pilihStatus">Status Kehadiran</label>
                    <select id="pilihStatus">
                        <option value="">-- Kosongkan (Tanpa Status) --</option>
                        <option value="H">H - Hadir</option>
                        <option value="S">S - Sakit</option>
                        <option value="I">I - Izin</option>
                        <option value="A">A - Alpha</option>
                    </select>
                </div>
                <button type="button" class="btn btn-primary" onclick="simpanStatusAbsensi()">
                    <i class="fa-solid fa-floppy-disk"></i> Simpan
                </button>
                <button type="button" class="btn btn-ghost" onclick="tutupForm('formEditStatus')">
                    <i class="fa-solid fa-xmark"></i> Batal
                </button>
            </div>
            <p class="panel-msg" id="pesanEditStatus"></p>
        </div>

        <!-- Tabel Rekap -->
        <div class="glass-card table-card" id="areaCetak">
            <!-- Kop / Header khusus saat print -->
            <div class="print-only print-header">
                <h2 id="printJudul">LAPORAN REKAPITULASI ABSENSI SISWA</h2>
                <p id="printSubJudul" style="font-weight:bold;margin-bottom:3px;"></p>
                <p id="printInfoStats"></p>
            </div>

            <div class="card-header no-print">
                <div style="display:flex;align-items:center;gap:10px;">
                    <div class="card-header-icon"><i class="fa-solid fa-clipboard-list" style="color:var(--pink-600);font-size:18px;"></i></div>
                    <div>
                        <div class="card-title" id="judulTabel">Rekap Absensi</div>
                        <div class="table-subtitle" id="ringkasanStats">-</div>
                    </div>
                </div>
            </div>

            <div class="table-wrap">
                <table class="absen-table" id="tabelAbsensi">
                    <thead id="headerTabel"></thead>
                    <tbody id="bodyTabel">
                        <tr class="empty-row"><td colspan="35"><i class="fa-solid fa-spinner fa-spin"></i> Memuat data...</td></tr>
                    </tbody>
                    <tfoot id="footerTabel"></tfoot>
                </table>
            </div>

            <!-- Tanda Tangan khusus saat cetak/print -->
            <div class="print-only print-signature">
                <div class="sig-box">
                    <p>Mengetahui,</p>
                    <p><strong>Kepala Sekolah</strong></p>
                    <div style="height:55px;"></div>
                    <p><strong>( .................................................... )</strong></p>
                    <p>NIP. ....................................................</p>
                </div>
                <div class="sig-box">
                    <p id="printLokasiTanggal">Indonesia, 16 September 2026</p>
                    <p><strong>Wali Kelas / Guru Piket</strong></p>
                    <div style="height:55px;"></div>
                    <p><strong>( .................................................... )</strong></p>
                    <p>NIP. ....................................................</p>
                </div>
            </div>
        </div>

    </main>
</div>

<script>
    // ==========================================
    // NAVIGASI SIDEBAR
    // ==========================================
    function setActiveNav(el) {
        document.querySelectorAll('.nav-item').forEach(function(item) {
            item.classList.remove('active');
        });
        el.classList.add('active');
    }

    function scrollToEl(id) {
        var el = document.getElementById(id);
        if (el) {
            setTimeout(function() {
                el.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }, 100);
        }
    }

    // ==========================================
    // KONFIGURASI
    // ==========================================
    const API_URL = 'https://script.google.com/macros/s/AKfycbzyGwi4L55DZwGYtC0XeDSo6DCzMavsH7nxR31ewTeuC9EjBf7ZqJlruRTuf8EjsqCycQ/exec';

    const NAMA_BULAN = [
        "Januari","Februari","Maret","April","Mei","Juni",
        "Juli","Agustus","September","Oktober","November","Desember"
    ];

    let contextEdit = { nama:"", tanggal:0, bulan:-1, tahun:-1 };

    // ==========================================
    // CEK LOGIN
    // ==========================================
    window.onload = function () {
        const isLoggedIn = sessionStorage.getItem("isAdmin");
        if (!isLoggedIn || isLoggedIn !== "true") {
            alert("Sesi habis atau belum login. Silakan login kembali.");
            window.location.href = "../login/index.php";
            return;
        }
        const now = new Date();
        var defaultBulan = (now.getFullYear() === 2026) ? now.getMonth() : 0;
        document.getElementById("pilihBulan").value = defaultBulan;
        document.getElementById("pilihTahun").value = 2026;
        muatData();
    };

    // ==========================================
    // LOGOUT
    // ==========================================
    function logout() {
        if (confirm("Apakah Anda yakin ingin logout?")) {
            sessionStorage.removeItem("isAdmin");
            window.location.href = "index.php?action=logout";
        }
    }

    // ==========================================
    // KEY LOCALSTORAGE
    // ==========================================
    function getKeyAbsensi(b,t){ return "absensi_"+NAMA_BULAN[b]+"_"+t; }
    function getKeyLibur(b,t)  { return "libur_"+NAMA_BULAN[b]+"_"+t;   }
    function getKeySiswa()     { return "daftar_siswa"; }

    // ==========================================
    // CRUD LOCALSTORAGE
    // ==========================================
    function getDaftarSiswa(){ var r=localStorage.getItem(getKeySiswa()); return r?JSON.parse(r):[]; }
    function simpanDaftarSiswa(d){ localStorage.setItem(getKeySiswa(),JSON.stringify(d)); }
    function getDataAbsensi(b,t){ var r=localStorage.getItem(getKeyAbsensi(b,t)); return r?JSON.parse(r):{}; }
    function simpanDataAbsensi(b,t,d){ localStorage.setItem(getKeyAbsensi(b,t),JSON.stringify(d)); }
    function getDataLibur(b,t){
        var r=localStorage.getItem(getKeyLibur(b,t));
        if(!r) return [];
        try {
            var parsed = JSON.parse(r);
            // Libur normal tidak melebihi 15 hari. Jika lebih, itu data korup akibat bug #ffffff di script lama
            if(Array.isArray(parsed) && parsed.length > 15) {
                localStorage.removeItem(getKeyLibur(b,t));
                return [];
            }
            return parsed;
        } catch(e) { return []; }
    }
    function simpanDataLibur(b,t,d){
        if(Array.isArray(d) && d.length > 15) return;
        localStorage.setItem(getKeyLibur(b,t),JSON.stringify(d));
    }

    // ==========================================
    // HELPER
    // ==========================================
    function jumlahHariBulan(b,t){ return new Date(t,b+1,0).getDate(); }
    function formatTanggalUntukApi(t,b,d){ return t+"-"+String(b+1).padStart(2,"0")+"-"+String(d).padStart(2,"0"); }

    function normalisasiDaftarSiswa(data) {
        if (Array.isArray(data)) return data;
        if (data && Array.isArray(data.value)) return data.value;
        if (data && Array.isArray(data.students)) return data.students;
        return [];
    }

    function normalisasiDataLibur(data, totalHari) {
        var arr = [];
        if (Array.isArray(data)) arr = data;
        else if (data && Array.isArray(data.value)) arr = data.value;
        var res = arr.map(function(item) {
            if (typeof item === 'number') return item;
            if (typeof item === 'string' && item.includes('-')) {
                var p = item.split('-');
                return parseInt(p[p.length - 1], 10);
            }
            return parseInt(item, 10);
        }).filter(function(n) { return !isNaN(n) && n >= 1 && n <= 31; });

        // Pengaman: Jika data libur >= 15 hari atau mendekati total hari (misal 30 hari libur karena sheet kosong),
        // ini adalah anomali cell putih di script lama. Kembalikan array kosong!
        if (res.length > 15 || (totalHari && res.length >= (totalHari - 2))) {
            return [];
        }
        return res;
    }

    function getSemuaTanggalLibur(bulan, tahun, totalHari, dataLiburServer) {
        var liburSet = new Set(dataLiburServer || []);
        // Otomatis masukkan semua hari Minggu sebagai tanggal merah
        for (var d = 1; d <= totalHari; d++) {
            var dt = new Date(tahun, bulan, d);
            if (dt.getDay() === 0) {
                liburSet.add(d);
            }
        }
        return Array.from(liburSet).sort(function(a, b) { return a - b; });
    }

    // ==========================================
    // MUAT DATA (Sinkron dengan Spreadsheet)
    // ==========================================
    function muatData() {
        var bulan = parseInt(document.getElementById("pilihBulan").value);
        var tahun = 2026;
        var totalHari   = jumlahHariBulan(bulan, tahun);
        var dataAbsensi = getDataAbsensi(bulan, tahun);
        var namaBulan   = NAMA_BULAN[bulan];

        document.getElementById("judulTabel").textContent = "Rekap Absensi - " + namaBulan + " " + tahun;
        document.getElementById("bodyTabel").innerHTML = "<tr class='empty-row'><td colspan='42'><i class='fa-solid fa-spinner fa-spin'></i> Memuat data dari server...</td></tr>";

        var urlGetSiswa = API_URL + "?action=getStudents&monthNum=" + (bulan+1);
        var urlGetLibur = API_URL + "?action=getHolidays&monthNum=" + (bulan+1);
        var urlGetAbsen = API_URL + "?action=getAttendance&monthNum=" + (bulan+1);

        Promise.all([
            fetch(urlGetSiswa, { method: "GET" })
                .then(function(r){ return r.text(); })
                .then(function(txt){
                    try { return JSON.parse(txt); } catch(e) { return getDaftarSiswa(); }
                }),
            fetch(urlGetLibur, { method: "GET" })
                .then(function(r){ return r.text(); })
                .then(function(txt){
                    try { return JSON.parse(txt); } catch(e) { return getDataLibur(bulan, tahun); }
                }),
            fetch(urlGetAbsen, { method: "GET" })
                .then(function(r){ return r.text(); })
                .then(function(txt){
                    try {
                        var res = JSON.parse(txt);
                        return (typeof res === 'object' && res !== null && !Array.isArray(res)) ? res : null;
                    } catch(e) { return null; }
                })
        ])
        .then(function(results){
            var daftarSiswa   = normalisasiDaftarSiswa(results[0]);
            var dataLiburRaw  = normalisasiDataLibur(results[1], totalHari);
            var dataLibur     = getSemuaTanggalLibur(bulan, tahun, totalHari, dataLiburRaw);
            var remoteAbsen   = results[2];

            // Jika ada data presensi dari spreadsheet, gabungkan ke data lokal
            if (remoteAbsen && typeof remoteAbsen === 'object') {
                dataAbsensi = Object.assign({}, dataAbsensi, remoteAbsen);
                simpanDataAbsensi(bulan, tahun, dataAbsensi);
            }

            if (daftarSiswa.length > 0) simpanDaftarSiswa(daftarSiswa);
            if (dataLiburRaw.length > 0) simpanDataLibur(bulan, tahun, dataLiburRaw);

            renderRingkasan(daftarSiswa, dataAbsensi, totalHari, dataLibur);
            renderTabel(bulan, tahun, totalHari, daftarSiswa, dataAbsensi, dataLibur);
            perbaruiDaftarLiburUI(dataLiburRaw);
        })
        .catch(function(err){
            var daftarSiswaLokal = getDaftarSiswa();
            var dataLiburLokal   = getSemuaTanggalLibur(bulan, tahun, totalHari, getDataLibur(bulan, tahun));
            renderRingkasan(daftarSiswaLokal, dataAbsensi, totalHari, dataLiburLokal);
            renderTabel(bulan, tahun, totalHari, daftarSiswaLokal, dataAbsensi, dataLiburLokal);
            perbaruiDaftarLiburUI(getDataLibur(bulan, tahun));
        });
    }

    // ==========================================
    // RENDER RINGKASAN (Stats)
    // ==========================================
    function renderRingkasan(daftarSiswa, dataAbsensi, totalHari, dataLibur) {
        var hariEfektif = totalHari - dataLibur.length;
        if (hariEfektif < 0) hariEfektif = 0;
        var tH=0,tS=0,tI=0,tA=0;
        daftarSiswa.forEach(function(nama){
            var absen = dataAbsensi[nama] || {};
            for(var d=1;d<=totalHari;d++){
                var s = absen[d] || "";
                if(s==="H")tH++; else if(s==="S")tS++; else if(s==="I")tI++;
                else if(s==="A")tA++;
            }
        });
        document.getElementById("statSiswa").textContent      = daftarSiswa.length;
        document.getElementById("statHariEfektif").textContent = hariEfektif;
        document.getElementById("statH").textContent          = tH;
        document.getElementById("statS").textContent          = tS;
        document.getElementById("statI").textContent          = tI;
        document.getElementById("statA").textContent          = tA;

        document.getElementById("ringkasanStats").textContent =
            daftarSiswa.length + " Siswa | " + hariEfektif + " Hari Efektif";
    }

    // ==========================================
    // STATUS COLOR MAP (Sinkron Persis Warna Spreadsheet)
    // ==========================================
    var statusColor = {
        "H": "background:#d9ead3;color:#274e13;border:1px solid #b6d7a8;", // Hijau
        "S": "background:#fff2cc;color:#7f6000;border:1px solid #ffe599;", // Kuning
        "I": "background:#c9daf8;color:#1155cc;border:1px solid #a4c2f4;", // Biru muda
        "A": "background:#f4cccc;color:#990000;border:1px solid #ea9999;"  // Merah
    };

    // ==========================================
    // RENDER TABEL (Dengan Tanggal Merah Segaris Merah Tanpa Huruf L)
    // ==========================================
    function renderTabel(bulan, tahun, totalHari, daftarSiswa, dataAbsensi, dataLibur) {
        // HEADER
        var headerHtml = "<tr><th>No</th><th>Nama Siswa</th>";
        for(var d=1;d<=totalHari;d++){
            var dt = new Date(tahun, bulan, d);
            var isMinggu = dt.getDay() === 0;
            var isLib = dataLibur.includes(d);
            if(isLib){
                headerHtml += "<th style='background:#f4cccc;color:#990000;font-weight:700;border:1px solid #ea9999;' title='" + (isMinggu ? "Hari Minggu" : "Hari Libur") + "'>" + d + "</th>";
            } else {
                headerHtml += "<th>" + d + "</th>";
            }
        }
        headerHtml += "<th style='background:#d9ead3;color:#274e13;font-weight:700;border:1px solid #b6d7a8;' title='Hadir (H)'>H</th>" +
                      "<th style='background:#fff2cc;color:#7f6000;font-weight:700;border:1px solid #ffe599;' title='Sakit (S)'>S</th>" +
                      "<th style='background:#c9daf8;color:#1155cc;font-weight:700;border:1px solid #a4c2f4;' title='Izin (I)'>I</th>" +
                      "<th style='background:#f4cccc;color:#990000;font-weight:700;border:1px solid #ea9999;' title='Alpha (A)'>A</th>" +
                      "<th class='col-aksi' style='min-width:170px;'>Aksi</th></tr>";
        document.getElementById("headerTabel").innerHTML = headerHtml;

        // BODY
        var bodyHtml = "";
        if(daftarSiswa.length === 0){
            bodyHtml = "<tr class='empty-row'><td colspan='" + (totalHari+7) + "'><i class='fa-solid fa-circle-info'></i> Belum ada data siswa di sheet ini.</td></tr>";
        } else {
            daftarSiswa.forEach(function(nama, idx){
                var absen = dataAbsensi[nama] || {};
                var cH=0,cS=0,cI=0,cA=0;
                var namaSafe = String(nama).replace(/\\/g,"\\\\").replace(/'/g,"\\'");
                var row = "<tr><td>" + (idx+1) + "</td><td style='text-align:left;font-weight:500;padding-left:10px;'>" + nama + "</td>";
                for(var d=1;d<=totalHari;d++){
                    var status  = absen[d] || "";
                    var isLibur = dataLibur.includes(d);
                    if(isLibur){
                        // Tanggal Merah (Cukup warna merah saja, TANPA huruf L)
                        row += "<td style='background:#f4cccc;border:1px solid #ea9999;' title='Tanggal Merah (Libur)'>" + (status ? status : "") + "</td>";
                    } else {
                        var st = statusColor[status] || "";
                        if(status==="H")cH++;
                        else if(status==="S")cS++;
                        else if(status==="I")cI++;
                        else if(status==="A")cA++;
                        var styleAttr = st ? " style='" + st + "font-weight:600;border-radius:4px;'" : "";
                        row += "<td" + styleAttr + " class='cell-clickable'" +
                               " onclick=\"bukaEditStatus('" + namaSafe + "'," + d + "," + bulan + "," + tahun + ")\"" +
                               " title='Klik untuk edit status'>" + status + "</td>";
                    }
                }
                // Kolom Rekapitulasi Sinkron dengan Warna Spreadsheet (H, S, I, A)
                row += "<td style='background:#d9ead3;color:#274e13;font-weight:700;border:1px solid #b6d7a8;'>" + cH + "</td>" +
                       "<td style='background:#fff2cc;color:#7f6000;font-weight:700;border:1px solid #ffe599;'>" + cS + "</td>" +
                       "<td style='background:#c9daf8;color:#1155cc;font-weight:700;border:1px solid #a4c2f4;'>" + cI + "</td>" +
                       "<td style='background:#f4cccc;color:#990000;font-weight:700;border:1px solid #ea9999;'>" + cA + "</td>";

                // Kolom Aksi
                row += "<td class='col-aksi' style='white-space:nowrap;text-align:center;'>" +
                       "<div style='display:inline-flex;gap:6px;align-items:center;justify-content:center;'>" +
                       "<button type='button' class='btn btn-warning btn-sm' onclick=\"bukaEditSiswa('" + namaSafe + "')\" title='Ubah Data Absensi Siswa'>" +
                       "<i class='fa-solid fa-pen-to-square'></i> Ubah" +
                       "</button>" +
                       "<button type='button' class='btn btn-danger btn-sm' onclick=\"hapusSiswa('" + namaSafe + "')\" title='Hapus Data Siswa'>" +
                       "<i class='fa-solid fa-trash'></i> Hapus Data" +
                       "</button>" +
                       "</div>" +
                       "</td>";
                row += "</tr>";
                bodyHtml += row;
            });
        }
        document.getElementById("bodyTabel").innerHTML = bodyHtml;

        // FOOTER
        var footHtml = "<tr><td colspan='2' style='text-align:left;padding-left:14px;font-weight:700;'>Total Hadir (H) / Hari</td>";
        for(var d=1;d<=totalHari;d++){
            if(dataLibur.includes(d)){
                footHtml += "<td style='background:#f4cccc;border:1px solid #ea9999;'></td>";
            } else {
                var tot = 0;
                daftarSiswa.forEach(function(nama){ if((dataAbsensi[nama]||{})[d]==="H") tot++; });
                footHtml += "<td style='font-weight:600;'>" + (tot>0?tot:"") + "</td>";
            }
        }
        footHtml += "<td colspan='4' style='background:#f5f5f5;'></td><td class='col-aksi'></td></tr>";
        document.getElementById("footerTabel").innerHTML = footHtml;
    }

    // ==========================================
    // TAMBAH SISWA
    // ==========================================
    function tampilkanFormTambahSiswa(){
        document.getElementById("formTambahSiswa").style.display = "block";
        document.getElementById("pesanTambahSiswa").textContent  = "";
        document.getElementById("inputNamaSiswa").value = "";
        document.getElementById("inputNamaSiswa").focus();
    }

    function simpanSiswa(){
        var pesan = document.getElementById("pesanTambahSiswa");
        pesan.innerHTML = '<i class="fa-solid fa-circle-info"></i> Daftar siswa dikelola langsung di <strong>Google Sheet</strong>. ' +
            'Tambah siswa pada sheet bulan yang sesuai (Kolom C, mulai baris 4), ' +
            'lalu klik <em>Muat Data</em> untuk memperbarui tampilan.';
        pesan.style.color = "#7a4060";
    }

    // ==========================================
    // HAPUS SISWA
    // ==========================================
    function hapusSiswa(nama){
        if(!confirm('Hapus data absensi untuk "' + nama + '"?\nCatatan: untuk menghapus permanen dari daftar siswa, hapus langsung di Google Sheet.')) return;
        Object.keys(localStorage).forEach(function(key){
            if(key.startsWith("absensi_")){
                var data = JSON.parse(localStorage.getItem(key));
                if(data[nama]){ delete data[nama]; localStorage.setItem(key,JSON.stringify(data)); }
            }
        });
        muatData();
    }

    // ==========================================
    // EDIT STATUS ABSENSI
    // ==========================================
    function onGantiTanggalEdit() {
        var tgl = parseInt(document.getElementById("editPilihTanggal").value);
        contextEdit.tanggal = tgl;
        var dataAbsensi = getDataAbsensi(contextEdit.bulan, contextEdit.tahun);
        var statusSaatIni = (dataAbsensi[contextEdit.nama] || {})[tgl] || "";
        document.getElementById("pilihStatus").value = statusSaatIni;
        document.getElementById("pesanEditStatus").textContent = "";
    }

    function bukaFormEdit(nama, tanggal, bulan, tahun) {
        var totalHari = jumlahHariBulan(bulan, tahun);
        var now = new Date();
        var defaultTgl = tanggal || (bulan === now.getMonth() && tahun === now.getFullYear() ? now.getDate() : 1);
        if (defaultTgl > totalHari) defaultTgl = totalHari;

        contextEdit = { nama: nama, tanggal: defaultTgl, bulan: bulan, tahun: tahun };

        document.getElementById("editNamaSiswa").value = nama;

        var selectTgl = document.getElementById("editPilihTanggal");
        selectTgl.innerHTML = "";
        var dataLibur = getSemuaTanggalLibur(bulan, tahun, totalHari, getDataLibur(bulan, tahun));
        var namaHariList = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];

        for (var d = 1; d <= totalHari; d++) {
            var tglObj = new Date(tahun, bulan, d);
            var namaHari = namaHariList[tglObj.getDay()];
            var isLib = dataLibur.includes(d);
            var opt = document.createElement("option");
            opt.value = d;
            opt.textContent = "Tanggal " + d + " - " + namaHari + (isLib ? " (Libur)" : "");
            if (d === defaultTgl) opt.selected = true;
            selectTgl.appendChild(opt);
        }

        var dataAbsensi = getDataAbsensi(bulan, tahun);
        var statusSaatIni = (dataAbsensi[nama] || {})[defaultTgl] || "";
        document.getElementById("pilihStatus").value = statusSaatIni;
        document.getElementById("pesanEditStatus").textContent = "";

        var formEl = document.getElementById("formEditStatus");
        formEl.style.display = "block";
        scrollToEl("formEditStatus");
    }

    function bukaEditStatus(nama, tanggal, bulan, tahun){
        bukaFormEdit(nama, tanggal, bulan, tahun);
    }

    function bukaEditSiswa(nama){
        var bulan = parseInt(document.getElementById("pilihBulan").value);
        var tahun = parseInt(document.getElementById("pilihTahun").value);
        bukaFormEdit(nama, null, bulan, tahun);
    }

    function simpanStatusAbsensi(){
        var nama    = contextEdit.nama;
        var tanggal = contextEdit.tanggal;
        var bulan   = contextEdit.bulan;
        var tahun   = contextEdit.tahun;
        var status  = document.getElementById("pilihStatus").value;
        var pesan   = document.getElementById("pesanEditStatus");

        var dataAbsensi = getDataAbsensi(bulan, tahun);
        if(!dataAbsensi[nama]) dataAbsensi[nama] = {};

        if(status === ""){
            delete dataAbsensi[nama][tanggal];
            simpanDataAbsensi(bulan, tahun, dataAbsensi);
            pesan.innerHTML = "<i class='fa-solid fa-circle-check' style='color:#2e7d32;'></i> Status dikosongkan (tersimpan lokal).";
            muatData(); return;
        }

        dataAbsensi[nama][tanggal] = status;
        simpanDataAbsensi(bulan, tahun, dataAbsensi);
        muatData();

        pesan.innerHTML = "<i class='fa-solid fa-spinner fa-spin'></i> Mengirim ke server...";
        var tanggalStr = formatTanggalUntukApi(tahun, bulan, tanggal);

        fetch(API_URL, {
            method: "POST",
            body: JSON.stringify({action:"saveAttendance", student:nama, date:tanggalStr, status:status})
        })
        .then(function(res){ return res.json(); })
        .then(function(data){
            pesan.innerHTML = data.success
                ? "<i class='fa-solid fa-circle-check' style='color:#2e7d32;'></i> Berhasil disimpan ke Google Sheet!"
                : "<i class='fa-solid fa-triangle-exclamation' style='color:#e65100;'></i> Tersimpan lokal, gagal ke Sheet: " + data.message;
        })
        .catch(function(err){
            pesan.innerHTML = "<i class='fa-solid fa-triangle-exclamation' style='color:#e65100;'></i> Tersimpan lokal, gagal ke server: " + err.message;
        });
    }

    // ==========================================
    // KELOLA HARI LIBUR (Segaris Merah di Sheet)
    // ==========================================
    function tampilkanFormLibur(){
        var bulan = parseInt(document.getElementById("pilihBulan").value);
        var tahun = 2026;
        var bb    = String(bulan+1).padStart(2,"0");
        var totalHari = jumlahHariBulan(bulan, tahun);
        document.getElementById("tanggalLibur").value     = tahun+"-"+bb+"-01";
        document.getElementById("tanggalLibur").min       = tahun+"-"+bb+"-01";
        document.getElementById("tanggalLibur").max       = tahun+"-"+bb+"-"+String(totalHari).padStart(2,"0");
        document.getElementById("keteranganLibur").value  = "";
        document.getElementById("pesanLibur").textContent = "";
        document.getElementById("formLibur").style.display = "block";
        perbaruiDaftarLiburUI();
    }

    function perbaruiDaftarLiburUI(dataLiburServer) {
        var el = document.getElementById("daftarLiburBulanIni");
        if (!el) return;
        var bulan = parseInt(document.getElementById("pilihBulan").value);
        var tahun = 2026;
        var liburArr = (dataLiburServer && dataLiburServer.length > 0) ? dataLiburServer : getDataLibur(bulan, tahun);
        
        // Filter bukan hari Minggu
        var liburKhusus = liburArr.filter(function(d) {
            var dt = new Date(tahun, bulan, d);
            return dt.getDay() !== 0;
        });

        if (liburKhusus.length === 0) {
            el.innerHTML = "<span style='font-size:0.8rem;color:var(--text-light);'>Belum ada libur khusus yang ditetapkan di bulan " + NAMA_BULAN[bulan] + " 2026 (hanya hari Minggu).</span>";
            return;
        }

        var html = "<div style='font-weight:600;font-size:0.82rem;color:var(--text-mid);margin-bottom:6px;'>Libur Khusus Bulan Ini (Segaris Merah):</div><div style='display:flex;flex-wrap:wrap;gap:6px;'>";
        liburKhusus.forEach(function(d) {
            html += "<span style='display:inline-flex;align-items:center;gap:6px;background:#f4cccc;color:#990000;border:1px solid #ea9999;padding:4px 10px;border-radius:16px;font-size:0.78rem;font-weight:600;'>" +
                    "Tanggal " + d + " " + NAMA_BULAN[bulan] +
                    "<button type='button' onclick='batalkanLiburTanggal(" + d + ")' title='Batalkan libur ini' style='background:none;border:none;color:#990000;cursor:pointer;font-weight:bold;font-size:0.85rem;padding:0 2px;line-height:1;'>✕</button>" +
                    "</span>";
        });
        html += "</div>";
        el.innerHTML = html;
    }

    function batalkanLiburTanggal(d) {
        var bulan = parseInt(document.getElementById("pilihBulan").value);
        var tahun = 2026;
        var tglStr = formatTanggalUntukApi(tahun, bulan, d);
        document.getElementById("tanggalLibur").value = tglStr;
        batalkanLibur();
    }

    function tetapkanLibur(){
        var tanggalLibur = document.getElementById("tanggalLibur").value;
        var keterangan   = document.getElementById("keteranganLibur").value;
        var pesan        = document.getElementById("pesanLibur");
        if(!tanggalLibur){ pesan.textContent="Pilih tanggal terlebih dahulu."; return; }

        var bulan   = parseInt(document.getElementById("pilihBulan").value);
        var tahun   = 2026;
        var dateObj = new Date(tanggalLibur+"T00:00:00");
        var tanggal = dateObj.getDate();

        var dataLibur = getDataLibur(bulan, tahun);
        if(!dataLibur.includes(tanggal)){
            dataLibur.push(tanggal);
            dataLibur.sort(function(a,b){return a-b;});
            simpanDataLibur(bulan, tahun, dataLibur);
        }

        pesan.innerHTML = "<i class='fa-solid fa-spinner fa-spin'></i> Menetapkan libur di spreadsheet (segaris merah)...";
        fetch(API_URL,{method:"POST",body:JSON.stringify({action:"setHoliday",date:tanggalLibur,description:keterangan})})
        .then(function(res){return res.json();})
        .then(function(data){
            pesan.innerHTML = data.success
                ? "<i class='fa-solid fa-circle-check' style='color:#2e7d32;'></i> Tanggal "+tanggal+" "+NAMA_BULAN[bulan]+" berhasil ditetapkan sebagai hari libur (segaris merah di sheet)."
                : "<i class='fa-solid fa-triangle-exclamation' style='color:#e65100;'></i> Tersimpan lokal, info server: "+data.message;
            muatData();
        })
        .catch(function(err){
            pesan.innerHTML = "<i class='fa-solid fa-triangle-exclamation' style='color:#e65100;'></i> Tersimpan lokal, gagal ke server: "+err.message;
            muatData();
        });
    }

    function batalkanLibur(){
        var tanggalLibur = document.getElementById("tanggalLibur").value;
        var pesan        = document.getElementById("pesanLibur");
        if(!tanggalLibur){ pesan.textContent="Pilih tanggal terlebih dahulu."; return; }

        var bulan   = parseInt(document.getElementById("pilihBulan").value);
        var tahun   = 2026;
        var dateObj = new Date(tanggalLibur+"T00:00:00");
        var tanggal = dateObj.getDate();

        var dataLibur = getDataLibur(bulan, tahun).filter(function(d){return d!==tanggal;});
        simpanDataLibur(bulan, tahun, dataLibur);

        pesan.innerHTML = "<i class='fa-solid fa-spinner fa-spin'></i> Membatalkan libur di spreadsheet...";
        fetch(API_URL,{method:"POST",body:JSON.stringify({action:"cancelHoliday",date:tanggalLibur})})
        .then(function(res){return res.json();})
        .then(function(data){
            pesan.innerHTML = data.success
                ? "<i class='fa-solid fa-circle-check' style='color:#2e7d32;'></i> Libur tanggal "+tanggal+" "+NAMA_BULAN[bulan]+" berhasil dibatalkan di spreadsheet."
                : "<i class='fa-solid fa-triangle-exclamation' style='color:#e65100;'></i> Tersimpan lokal, info server: "+data.message;
            muatData();
        })
        .catch(function(err){
            pesan.innerHTML = "<i class='fa-solid fa-triangle-exclamation' style='color:#e65100;'></i> Tersimpan lokal, gagal ke server: "+err.message;
            muatData();
        });
    }

    // ==========================================
    // TUTUP FORM
    // ==========================================
    function tutupForm(idForm){ document.getElementById(idForm).style.display = "none"; }

    // ==========================================
    // CETAK / PRINT (Hanya Rekap Absensi)
    // ==========================================
    function cetakLaporan(){
        var bulan = parseInt(document.getElementById("pilihBulan").value);
        var tahun = 2026;
        var namaBulan = NAMA_BULAN[bulan];
        var totalHari = jumlahHariBulan(bulan, tahun);
        var dataLibur = getDataLibur(bulan, tahun);
        var hariEfektif = totalHari - dataLibur.length;
        var elSiswa = document.getElementById("statSiswa");
        var jumlahSiswa = elSiswa ? elSiswa.textContent : "0";

        document.getElementById("printJudul").textContent = "LAPORAN REKAPITULASI ABSENSI SISWA";
        document.getElementById("printSubJudul").textContent = "Periode: " + namaBulan + " 2026";
        document.getElementById("printInfoStats").textContent = "Jumlah Siswa: " + jumlahSiswa + " Orang | Hari Efektif: " + hariEfektif + " Hari";

        var today = new Date();
        var tglFormat = today.toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" });
        var elLokasi = document.getElementById("printLokasiTanggal");
        if (elLokasi) {
            elLokasi.textContent = tglFormat;
        }

        // Sembunyikan form pop-up saat cetak
        tutupForm("formTambahSiswa");
        tutupForm("formLibur");
        tutupForm("formEditStatus");

        window.print();
    }
</script>

</body>
</html>
