<?php
session_start();

// Handle sinkronisasi session PHP jika dipanggil via AJAX
if (isset($_POST['action']) && $_POST['action'] === 'set_session') {
    $_SESSION['isAdmin'] = true;
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode(['success' => true]);
    exit;
}

header('Content-Type: text/html; charset=UTF-8');
$appTitle = "Login — Rekap Absensi";
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $appTitle; ?></title>
    <meta name="description" content="Halaman login sistem rekap absensi siswa">
    <link rel="stylesheet" href="../asset/style.css">
</head>
<body>
<div class="login-page">
    <div class="login-card">

        <div class="login-logo">
            <div class="login-logo-icon">🌸</div>
            <div>
                <div class="login-title">ABSENSI</div>
            </div>
        </div>
        <p class="login-subtitle">Sistem Rekap Absensi Siswa</p>

        <form id="formLogin">
            <div class="login-field">
                <label for="username">Username</label>
                <div class="login-input-wrap">
                    <span class="icon">👤</span>
                    <input type="text" id="username" placeholder="Masukkan username" required>
                </div>
            </div>

            <div class="login-field">
                <label for="password">Password</label>
                <div class="login-input-wrap">
                    <span class="icon">🔒</span>
                    <input type="password" id="password" placeholder="Masukkan password" required>
                </div>
            </div>

            <button type="submit" id="tombolLogin" class="btn-login">Masuk ✨</button>
        </form>

        <p id="pesan-status" class="login-status"></p>
    </div>
</div>

<script>
    const API_URL = 'https://script.google.com/macros/s/AKfycbzyGwi4L55DZwGYtC0XeDSo6DCzMavsH7nxR31ewTeuC9EjBf7ZqJlruRTuf8EjsqCycQ/exec';
    const form = document.getElementById('formLogin');
    const pesanStatus = document.getElementById('pesan-status');
    const tombolLogin = document.getElementById('tombolLogin');

    form.addEventListener('submit', function (event) {
        event.preventDefault();
        const usn = document.getElementById('username').value;
        const pw  = document.getElementById('password').value;

        pesanStatus.textContent = '⏳ Sedang mengecek data...';
        pesanStatus.style.color = '';
        tombolLogin.disabled = true;

        const urlDenganParameter = `${API_URL}?username=${encodeURIComponent(usn)}&password=${encodeURIComponent(pw)}`;

        fetch(urlDenganParameter, { method: 'GET' })
            .then(response => response.text())
            .then(hasilTeks => {
                tombolLogin.disabled = false;
                const status = hasilTeks.trim();

                if (status === 'ADMIN') {
                    pesanStatus.textContent = '✅ Login berhasil! Mengalihkan...';
                    pesanStatus.style.color = '#2e7d32';
                    sessionStorage.setItem("isAdmin", "true");

                    var fd = new FormData();
                    fd.append('action', 'set_session');
                    fetch('index.php', { method: 'POST', body: fd })
                        .finally(function() {
                            window.location.href = "../dashboard/index.php";
                        });
                } else if (status === 'GAGAL') {
                    pesanStatus.textContent = '❌ Username atau password salah!';
                    pesanStatus.style.color = '#c62828';
                } else {
                    pesanStatus.textContent = status;
                    pesanStatus.style.color = '#c62828';
                }
            })
            .catch(error => {
                tombolLogin.disabled = false;
                pesanStatus.textContent = '⚠️ Gagal menghubungi server.';
                pesanStatus.style.color = '#c62828';
                console.error('Error detail:', error);
            });
    });
</script>
</body>
</html>
